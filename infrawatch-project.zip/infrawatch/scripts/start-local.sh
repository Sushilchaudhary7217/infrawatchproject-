#!/bin/bash
# ============================================================
# FILE: /home/infrawatch/scripts/start-local.sh
# PURPOSE: Local mein docker-compose se sab start karo
# ============================================================
set -e
cd /home/infrawatch

echo "Starting InfraWatch locally..."
docker-compose up -d

echo ""
echo "Waiting for services to be ready..."
sleep 8

echo ""
echo "======================================================"
echo "  InfraWatch is running!"
echo "======================================================"
echo "  Frontend:   http://localhost:3000"
echo "  Admin Panel: http://localhost:3002/admin"
echo "  API:        http://localhost:3001"
echo "  Health:     http://localhost:3001/health"
echo ""
echo "  Login: admin@infrawatch.cloud / Admin@InfraWatch2024"
echo "======================================================"
echo ""
echo "Logs dekhne ke liye: docker-compose logs -f backend"
echo "Stop karne ke liye:  docker-compose down"
