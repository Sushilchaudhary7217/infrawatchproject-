#!/bin/bash
# ============================================================
# FILE: /home/infrawatch/scripts/local-setup.sh
# PURPOSE: Local machine par ek baar chalao - sab kuch install
# COMMAND: chmod +x scripts/local-setup.sh && bash scripts/local-setup.sh
# ============================================================

set -e
echo "======================================================"
echo "  InfraWatch - Local Setup Script"
echo "  Ubuntu/Debian Linux"
echo "======================================================"

# ── Install Node.js 20 ────────────────────────────────────
if ! command -v node &>/dev/null; then
  echo "[1/6] Installing Node.js 20..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
else
  echo "[1/6] Node.js already installed: $(node -v)"
fi

# ── Install Docker ────────────────────────────────────────
if ! command -v docker &>/dev/null; then
  echo "[2/6] Installing Docker..."
  sudo apt-get update -y
  sudo apt-get install -y ca-certificates curl gnupg
  sudo install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
  sudo apt-get update -y
  sudo apt-get install -y docker-ce docker-ce-cli docker-compose-plugin
  sudo usermod -aG docker $USER
else
  echo "[2/6] Docker already installed"
fi

# ── Install Docker Compose ────────────────────────────────
if ! command -v docker-compose &>/dev/null; then
  echo "[3/6] Installing Docker Compose..."
  sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
  sudo chmod +x /usr/local/bin/docker-compose
else
  echo "[3/6] Docker Compose already installed"
fi

# ── Install AWS CLI ───────────────────────────────────────
if ! command -v aws &>/dev/null; then
  echo "[4/6] Installing AWS CLI..."
  curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "/tmp/awscliv2.zip"
  sudo apt-get install -y unzip
  unzip -q /tmp/awscliv2.zip -d /tmp/
  sudo /tmp/aws/install
  rm -rf /tmp/aws /tmp/awscliv2.zip
else
  echo "[4/6] AWS CLI already installed: $(aws --version)"
fi

# ── Install Terraform ─────────────────────────────────────
if ! command -v terraform &>/dev/null; then
  echo "[5/6] Installing Terraform..."
  sudo apt-get install -y gnupg software-properties-common
  wget -O- https://apt.releases.hashicorp.com/gpg | sudo gpg --dearmor -o /usr/share/keyrings/hashicorp-archive-keyring.gpg
  echo "deb [signed-by=/usr/share/keyrings/hashicorp-archive-keyring.gpg] https://apt.releases.hashicorp.com $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/hashicorp.list
  sudo apt-get update -y && sudo apt-get install -y terraform
else
  echo "[5/6] Terraform already installed: $(terraform -version | head -1)"
fi

# ── npm install for all sub-projects ─────────────────────
echo "[6/6] Installing npm dependencies..."
cd /home/infrawatch/backend      && npm install --silent
cd /home/infrawatch/frontend     && npm install --silent
cd /home/infrawatch/admin-panel  && npm install --silent

echo ""
echo "======================================================"
echo "  Setup Complete!"
echo "======================================================"
echo ""
echo "  NEXT STEPS:"
echo "  1. Edit backend/.env  (AWS keys, DB password daalo)"
echo "  2. Run: bash scripts/start-local.sh"
echo "  3. Browser mein kholo: http://localhost:3000"
echo "  4. Admin panel:         http://localhost:3002/admin"
echo "  5. API health check:    http://localhost:3001/health"
echo ""
