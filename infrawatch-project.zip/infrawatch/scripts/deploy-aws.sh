#!/bin/bash
# ============================================================
# FILE: /home/infrawatch/scripts/deploy-aws.sh
# PURPOSE: EC2 par deploy karo - local se SSH ke through
# USAGE: bash scripts/deploy-aws.sh <EC2_IP> <KEY_FILE>
# EXAMPLE: bash scripts/deploy-aws.sh 13.235.12.45 infrawatch-key.pem
# ============================================================
set -e

EC2_IP=${1:-"YOUR_EC2_IP"}
KEY_FILE=${2:-"infrawatch-key.pem"}
REMOTE_USER="ubuntu"
PROJECT_DIR="/home/infrawatch"

if [ "$EC2_IP" = "YOUR_EC2_IP" ]; then
  echo "ERROR: EC2 IP daao"
  echo "Usage: bash deploy-aws.sh <EC2_IP> <KEY_FILE>"
  exit 1
fi

echo "======================================================"
echo "  Deploying InfraWatch to AWS EC2: $EC2_IP"
echo "======================================================"

# ── Build frontend + admin ────────────────────────────────
echo "[1/5] Building frontend..."
cd /home/infrawatch/frontend    && npm run build
echo "[1/5] Building admin panel..."
cd /home/infrawatch/admin-panel && npm run build

# ── Copy files to EC2 ────────────────────────────────────
echo "[2/5] Copying files to EC2..."
ssh -i "$KEY_FILE" -o StrictHostKeyChecking=no "$REMOTE_USER@$EC2_IP" "mkdir -p $PROJECT_DIR"
rsync -avz --exclude 'node_modules' --exclude '.git' \
  -e "ssh -i $KEY_FILE -o StrictHostKeyChecking=no" \
  /home/infrawatch/ "$REMOTE_USER@$EC2_IP:$PROJECT_DIR/"

# ── Setup server ──────────────────────────────────────────
echo "[3/5] Setting up server..."
ssh -i "$KEY_FILE" "$REMOTE_USER@$EC2_IP" << 'ENDSSH'
  cd /home/infrawatch
  # Node modules install
  cd backend && npm install --production && cd ..
  # PM2 install
  sudo npm install -g pm2
  # PostgreSQL database create
  sudo -u postgres psql -c "CREATE DATABASE infrawatch_db;" 2>/dev/null || true
  sudo -u postgres psql -c "CREATE USER infrawatch_user WITH PASSWORD 'InfraWatch@2024';" 2>/dev/null || true
  sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE infrawatch_db TO infrawatch_user;" 2>/dev/null || true
ENDSSH

# ── Start backend with PM2 ────────────────────────────────
echo "[4/5] Starting backend..."
ssh -i "$KEY_FILE" "$REMOTE_USER@$EC2_IP" << 'ENDSSH'
  cd /home/infrawatch/backend
  pm2 delete infrawatch-backend 2>/dev/null || true
  pm2 start src/app.js --name infrawatch-backend
  pm2 save
  pm2 startup | tail -1 | bash
ENDSSH

# ── Setup Nginx ───────────────────────────────────────────
echo "[5/5] Configuring Nginx..."
ssh -i "$KEY_FILE" "$REMOTE_USER@$EC2_IP" << ENDSSH
  sudo cp /home/infrawatch/nginx/infrawatch.conf /etc/nginx/sites-available/
  sudo ln -sf /etc/nginx/sites-available/infrawatch.conf /etc/nginx/sites-enabled/
  sudo rm -f /etc/nginx/sites-enabled/default
  sudo nginx -t && sudo systemctl reload nginx
ENDSSH

echo ""
echo "======================================================"
echo "  Deploy Complete!"
echo "======================================================"
echo "  Site:  http://$EC2_IP"
echo "  API:   http://$EC2_IP:3001/health"
echo ""
echo "  SSL ke liye:"
echo "  ssh -i $KEY_FILE $REMOTE_USER@$EC2_IP"
echo "  sudo apt install certbot python3-certbot-nginx -y"
echo "  sudo certbot --nginx -d infrawatch.cloud -d api.infrawatch.cloud -d admin.infrawatch.cloud"
echo "======================================================"
