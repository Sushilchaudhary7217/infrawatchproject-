// FILE: /home/infrawatch/admin-panel/src/main.jsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import AdminApp from './App';
ReactDOM.createRoot(document.getElementById('root')).render(<React.StrictMode><AdminApp /></React.StrictMode>);
