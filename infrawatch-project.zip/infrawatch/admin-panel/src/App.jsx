// FILE: /home/infrawatch/admin-panel/src/App.jsx
// Full admin panel - ek hi file mein saari pages
import React, { useEffect, useState, createContext, useContext } from 'react';
import axios from 'axios';
import { BrowserRouter, Routes, Route, NavLink, Navigate } from 'react-router-dom';

const API = import.meta.env.VITE_API_URL || 'http://localhost:3001';
const AuthCtx = createContext(null);

function useAuth() { return useContext(AuthCtx); }

const api = axios.create({ baseURL: API });
api.interceptors.request.use(cfg => {
  const t = localStorage.getItem('admin_token');
  if (t) cfg.headers.Authorization = `Bearer ${t}`;
  return cfg;
});

// ─── Login ────────────────────────────────────────────────
function AdminLogin() {
  const [email, setEmail] = useState('');
  const [pass,  setPass]  = useState('');
  const [err,   setErr]   = useState('');
  const { setToken, setUser } = useAuth();

  const submit = async (e) => {
    e.preventDefault(); setErr('');
    try {
      const { data } = await api.post('/api/auth/login', { email, password: pass });
      if (!['superadmin','admin'].includes(data.user.role)) {
        return setErr('Admin access only');
      }
      localStorage.setItem('admin_token', data.token);
      localStorage.setItem('admin_user', JSON.stringify(data.user));
      setToken(data.token); setUser(data.user);
    } catch (e) { setErr(e.response?.data?.error || 'Login failed'); }
  };

  return (
    <div style={{ minHeight:'100vh', background:'#1e293b', display:'flex', alignItems:'center', justifyContent:'center' }}>
      <div style={{ background:'white', borderRadius:16, padding:40, width:380, boxShadow:'0 25px 60px rgba(0,0,0,0.4)' }}>
        <div style={{ textAlign:'center', marginBottom:28 }}>
          <div style={{ width:52, height:52, background:'#7c3aed', borderRadius:12, display:'inline-flex', alignItems:'center', justifyContent:'center', color:'white', fontWeight:800, fontSize:20, marginBottom:12 }}>A</div>
          <h2 style={{ margin:0, fontSize:20, fontWeight:700 }}>Admin Panel</h2>
          <p style={{ margin:'4px 0 0', color:'#64748b', fontSize:13 }}>InfraWatch Control Center</p>
        </div>
        {err && <div style={{ background:'#fee2e2', color:'#991b1b', padding:'10px 14px', borderRadius:8, fontSize:13, marginBottom:14 }}>{err}</div>}
        <form onSubmit={submit}>
          <input type="email" placeholder="Admin email" value={email} onChange={e=>setEmail(e.target.value)}
            style={{ width:'100%', padding:'10px 14px', border:'1px solid #d1d5db', borderRadius:8, marginBottom:10, fontSize:14, boxSizing:'border-box' }} />
          <input type="password" placeholder="Password" value={pass} onChange={e=>setPass(e.target.value)}
            style={{ width:'100%', padding:'10px 14px', border:'1px solid #d1d5db', borderRadius:8, marginBottom:18, fontSize:14, boxSizing:'border-box' }} />
          <button type="submit" style={{ width:'100%', padding:11, background:'#7c3aed', color:'white', border:'none', borderRadius:8, fontSize:15, fontWeight:600, cursor:'pointer' }}>
            Login as Admin
          </button>
        </form>
      </div>
    </div>
  );
}

// ─── Shared Admin Layout ──────────────────────────────────
function AdminLayout({ children }) {
  const { user, logout } = useAuth();
  const navItems = [
    { path:'/admin',          label:'Overview'     },
    { path:'/admin/servers',  label:'Server Config' },
    { path:'/admin/alerts',   label:'Alert Rules'   },
    { path:'/admin/scaling',  label:'Auto Scaling'  },
    { path:'/admin/users',    label:'Users'         },
    { path:'/admin/settings', label:'Settings'      },
  ];
  return (
    <div style={{ display:'flex', minHeight:'100vh', background:'#f8fafc' }}>
      <aside style={{ width:220, background:'#1e1b4b', display:'flex', flexDirection:'column', position:'sticky', top:0, height:'100vh' }}>
        <div style={{ padding:'20px 16px', borderBottom:'1px solid #312e81' }}>
          <div style={{ color:'white', fontWeight:700, fontSize:15 }}>InfraWatch Admin</div>
          <div style={{ color:'#a5b4fc', fontSize:12, marginTop:4 }}>{user?.email}</div>
        </div>
        <nav style={{ flex:1, padding:'12px 8px' }}>
          {navItems.map(item => (
            <NavLink key={item.path} to={item.path} end={item.path==='/admin'}
              style={({ isActive }) => ({
                display:'block', padding:'9px 14px', borderRadius:8, marginBottom:3,
                textDecoration:'none', fontSize:14,
                color: isActive ? 'white' : '#a5b4fc',
                background: isActive ? '#4f46e5' : 'transparent',
                fontWeight: isActive ? 600 : 400,
              })}>{item.label}</NavLink>
          ))}
        </nav>
        <div style={{ padding:'12px 8px', borderTop:'1px solid #312e81' }}>
          <button onClick={logout} style={{ width:'100%', padding:'9px 14px', background:'transparent', border:'1px solid #312e81', borderRadius:8, color:'#a5b4fc', cursor:'pointer', fontSize:13 }}>
            Logout
          </button>
        </div>
      </aside>
      <main style={{ flex:1, padding:28, overflow:'auto' }}>{children}</main>
    </div>
  );
}

// ─── Overview Page ────────────────────────────────────────
function Overview() {
  const [settings, setSettings] = useState(null);
  const [stats,    setStats]    = useState({ servers:0, alerts:0 });

  useEffect(() => {
    api.get('/api/admin/settings').then(r => setSettings(r.data.settings)).catch(()=>{});
    Promise.all([
      api.get('/api/servers'),
      api.get('/api/alerts?status=active'),
    ]).then(([s, a]) => setStats({ servers: s.data.count, alerts: a.data.total })).catch(()=>{});
  }, []);

  return (
    <div>
      <h2 style={{ margin:'0 0 20px', fontSize:20, fontWeight:700 }}>System Overview</h2>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:16, marginBottom:28 }}>
        {[
          { label:'Total Servers',   value: stats.servers, color:'#0d9488' },
          { label:'Active Alerts',   value: stats.alerts,  color: stats.alerts>0?'#ef4444':'#22c55e' },
          { label:'AWS Region',      value: settings?.region || '—', color:'#7c3aed' },
        ].map(c => (
          <div key={c.label} style={{ background:'white', borderRadius:12, padding:'20px 24px', border:'1px solid #e2e8f0' }}>
            <div style={{ fontSize:12, color:'#94a3b8', marginBottom:6 }}>{c.label}</div>
            <div style={{ fontSize:28, fontWeight:700, color:c.color }}>{c.value}</div>
          </div>
        ))}
      </div>
      {settings && (
        <div style={{ background:'white', borderRadius:12, border:'1px solid #e2e8f0', padding:24 }}>
          <h3 style={{ margin:'0 0 16px', fontSize:16, fontWeight:600 }}>Current Thresholds</h3>
          <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12 }}>
            {[
              ['CPU Alert at',    `${settings.cpu_threshold}%`],
              ['Memory Alert at', `${settings.memory_threshold}%`],
              ['Disk Alert at',   `${settings.disk_threshold}%`],
            ].map(([k,v]) => (
              <div key={k} style={{ background:'#f8fafc', borderRadius:8, padding:'14px 16px' }}>
                <div style={{ fontSize:12, color:'#94a3b8', marginBottom:4 }}>{k}</div>
                <div style={{ fontSize:22, fontWeight:700, color:'#374151' }}>{v}</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Server Config Page ───────────────────────────────────
function ServerConfig() {
  const [servers, setServers] = useState([]);
  const [editing, setEditing] = useState(null);
  const [form, setForm]       = useState({});
  const [msg,  setMsg]        = useState('');

  useEffect(() => {
    api.get('/api/servers').then(r => setServers(r.data.servers || [])).catch(()=>{});
  }, []);

  const startEdit = (s) => { setEditing(s.id); setForm({ cpu_threshold: s.cpu_threshold, memory_threshold: s.memory_threshold, disk_threshold: s.disk_threshold }); setMsg(''); };

  const saveEdit = async (id) => {
    try {
      await api.put(`/api/servers/${id}`, form);
      setMsg('Saved!');
      setEditing(null);
      const r = await api.get('/api/servers');
      setServers(r.data.servers || []);
    } catch { setMsg('Save failed'); }
  };

  return (
    <div>
      <h2 style={{ margin:'0 0 6px', fontSize:20, fontWeight:700 }}>Server Config</h2>
      <p style={{ margin:'0 0 20px', color:'#64748b', fontSize:14 }}>Change alert thresholds for each server</p>
      {msg && <div style={{ background:'#dcfce7', color:'#166534', padding:'10px 16px', borderRadius:8, marginBottom:12, fontSize:13 }}>{msg}</div>}
      <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
        {servers.map(s => (
          <div key={s.id} style={{ background:'white', borderRadius:12, padding:20, border:'1px solid #e2e8f0' }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom: editing===s.id ? 16 : 0 }}>
              <div>
                <div style={{ fontWeight:600, fontSize:15 }}>{s.name}</div>
                <div style={{ fontSize:12, color:'#94a3b8', marginTop:2, fontFamily:'monospace' }}>{s.instance_id}</div>
              </div>
              {editing !== s.id
                ? <button onClick={() => startEdit(s)} style={{ background:'#ede9fe', color:'#5b21b6', border:'none', borderRadius:8, padding:'7px 16px', fontSize:13, fontWeight:500, cursor:'pointer' }}>Edit Thresholds</button>
                : <div style={{ display:'flex', gap:8 }}>
                    <button onClick={() => saveEdit(s.id)} style={{ background:'#0d9488', color:'white', border:'none', borderRadius:8, padding:'7px 16px', fontSize:13, fontWeight:500, cursor:'pointer' }}>Save</button>
                    <button onClick={() => setEditing(null)} style={{ background:'#f1f5f9', color:'#374151', border:'1px solid #e2e8f0', borderRadius:8, padding:'7px 16px', fontSize:13, cursor:'pointer' }}>Cancel</button>
                  </div>
              }
            </div>
            {editing === s.id && (
              <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:12 }}>
                {[['CPU %','cpu_threshold'],['Memory %','memory_threshold'],['Disk %','disk_threshold']].map(([lbl,key]) => (
                  <div key={key}>
                    <label style={{ fontSize:13, color:'#374151', fontWeight:500, display:'block', marginBottom:6 }}>{lbl} Alert Threshold</label>
                    <input type="number" min={20} max={99} value={form[key]}
                      onChange={e => setForm({...form, [key]: parseInt(e.target.value)})}
                      style={{ width:'100%', padding:'9px 12px', border:'1px solid #d1d5db', borderRadius:8, fontSize:15, fontWeight:600, boxSizing:'border-box' }} />
                    <div style={{ fontSize:11, color:'#94a3b8', marginTop:4 }}>Current: {s[key]}%</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Scaling Config Page ──────────────────────────────────
function ScalingConfig() {
  const [form, setForm] = useState({ asg_name:'', min_size:1, max_size:3, desired_capacity:1 });
  const [history, setHistory] = useState([]);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    api.get('/api/scaling/history').then(r => setHistory(r.data.events || [])).catch(()=>{});
  }, []);

  const updateASG = async (e) => {
    e.preventDefault();
    try {
      await api.put('/api/scaling/config', form);
      setMsg('ASG config updated successfully!');
    } catch (err) { setMsg('Update failed: ' + (err.response?.data?.error || '')); }
  };

  const manualTrigger = async (action) => {
    try {
      await api.post('/api/scaling/trigger', { asg_name: form.asg_name, action });
      setMsg(`${action} triggered!`);
      const r = await api.get('/api/scaling/history');
      setHistory(r.data.events || []);
    } catch (err) { setMsg('Trigger failed'); }
  };

  return (
    <div>
      <h2 style={{ margin:'0 0 6px', fontSize:20, fontWeight:700 }}>Auto Scaling Config</h2>
      <p style={{ margin:'0 0 20px', color:'#64748b', fontSize:14 }}>Control ASG min/max instances</p>
      {msg && <div style={{ background: msg.includes('fail') ? '#fee2e2':'#dcfce7', color: msg.includes('fail')?'#991b1b':'#166534', padding:'10px 16px', borderRadius:8, marginBottom:14, fontSize:13 }}>{msg}</div>}

      <div style={{ background:'white', borderRadius:12, border:'1px solid #e2e8f0', padding:24, marginBottom:20 }}>
        <form onSubmit={updateASG}>
          <div style={{ display:'grid', gridTemplateColumns:'2fr 1fr 1fr 1fr', gap:12, marginBottom:16 }}>
            {[
              ['ASG Name',          'asg_name',         'text',   'InfraWatch-ASG'],
              ['Min Instances',     'min_size',         'number', '1'],
              ['Max Instances',     'max_size',         'number', '3'],
              ['Desired Instances', 'desired_capacity', 'number', '1'],
            ].map(([lbl,key,type,ph]) => (
              <div key={key}>
                <label style={{ fontSize:13, fontWeight:500, display:'block', marginBottom:5 }}>{lbl}</label>
                <input type={type} placeholder={ph} value={form[key]}
                  onChange={e => setForm({...form, [key]: type==='number' ? parseInt(e.target.value) : e.target.value})}
                  style={{ width:'100%', padding:'9px 12px', border:'1px solid #d1d5db', borderRadius:8, fontSize:14, boxSizing:'border-box' }} />
              </div>
            ))}
          </div>
          <div style={{ display:'flex', gap:10 }}>
            <button type="submit" style={{ background:'#7c3aed', color:'white', border:'none', borderRadius:8, padding:'9px 20px', fontSize:14, fontWeight:600, cursor:'pointer' }}>Update ASG</button>
            <button type="button" onClick={() => manualTrigger('scale_out')} style={{ background:'#dcfce7', color:'#166534', border:'none', borderRadius:8, padding:'9px 18px', fontSize:14, fontWeight:500, cursor:'pointer' }}>Manual Scale Out</button>
            <button type="button" onClick={() => manualTrigger('scale_in')} style={{ background:'#fee2e2', color:'#991b1b', border:'none', borderRadius:8, padding:'9px 18px', fontSize:14, fontWeight:500, cursor:'pointer' }}>Manual Scale In</button>
          </div>
        </form>
      </div>

      <div style={{ background:'white', borderRadius:12, border:'1px solid #e2e8f0', overflow:'hidden' }}>
        <div style={{ padding:'14px 20px', borderBottom:'1px solid #e2e8f0', fontWeight:600, fontSize:14 }}>Scaling History</div>
        {history.length === 0
          ? <div style={{ padding:32, textAlign:'center', color:'#94a3b8' }}>No scaling events yet</div>
          : history.slice(0,10).map(e => (
              <div key={e.id} style={{ padding:'12px 20px', borderBottom:'1px solid #f1f5f9', display:'flex', justifyContent:'space-between', fontSize:14 }}>
                <span style={{ fontWeight:500 }}>{e.action} — {e.asg_name}</span>
                <span style={{ color:'#94a3b8', fontSize:12 }}>{new Date(e.createdAt).toLocaleString('en-IN')}</span>
              </div>
            ))
        }
      </div>
    </div>
  );
}

// ─── Users Page ───────────────────────────────────────────
function Users() {
  const [users, setUsers] = useState([]);
  const [form, setForm]   = useState({ name:'', email:'', password:'', role:'operator' });
  const [msg, setMsg]     = useState('');

  const fetchUsers = () => api.get('/api/admin/users').then(r => setUsers(r.data.users || [])).catch(()=>{});
  useEffect(() => { fetchUsers(); }, []);

  const addUser = async (e) => {
    e.preventDefault();
    try {
      await api.post('/api/admin/users', form);
      setMsg('User created!');
      setForm({ name:'', email:'', password:'', role:'operator' });
      fetchUsers();
    } catch (err) { setMsg(err.response?.data?.error || 'Failed'); }
  };

  const toggleActive = async (u) => {
    await api.put(`/api/admin/users/${u.id}`, { is_active: !u.is_active });
    fetchUsers();
  };

  const roleColors = { superadmin:'#ede9fe', admin:'#dbeafe', operator:'#dcfce7', viewer:'#f1f5f9' };
  const roleText   = { superadmin:'#5b21b6', admin:'#1e40af', operator:'#166534', viewer:'#374151' };

  return (
    <div>
      <h2 style={{ margin:'0 0 20px', fontSize:20, fontWeight:700 }}>User Management</h2>
      {msg && <div style={{ background:'#dcfce7', color:'#166534', padding:'10px 16px', borderRadius:8, marginBottom:14, fontSize:13 }}>{msg}</div>}

      <div style={{ background:'white', borderRadius:12, border:'1px solid #e2e8f0', padding:22, marginBottom:20 }}>
        <h3 style={{ margin:'0 0 14px', fontSize:15, fontWeight:600 }}>Add New User</h3>
        <form onSubmit={addUser}>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1fr', gap:12, marginBottom:14 }}>
            {[['Full Name','name','text'],['Email','email','email'],['Password','password','password']].map(([l,k,t]) => (
              <div key={k}>
                <label style={{ fontSize:13, fontWeight:500, display:'block', marginBottom:4 }}>{l}</label>
                <input type={t} value={form[k]} onChange={e => setForm({...form,[k]:e.target.value})}
                  style={{ width:'100%', padding:'8px 12px', border:'1px solid #d1d5db', borderRadius:8, fontSize:14, boxSizing:'border-box' }} />
              </div>
            ))}
            <div>
              <label style={{ fontSize:13, fontWeight:500, display:'block', marginBottom:4 }}>Role</label>
              <select value={form.role} onChange={e => setForm({...form, role:e.target.value})}
                style={{ width:'100%', padding:'9px 12px', border:'1px solid #d1d5db', borderRadius:8, fontSize:14, background:'white', boxSizing:'border-box' }}>
                <option value="operator">Operator</option>
                <option value="admin">Admin</option>
                <option value="viewer">Viewer (Read only)</option>
                <option value="superadmin">Super Admin</option>
              </select>
            </div>
          </div>
          <button type="submit" style={{ background:'#7c3aed', color:'white', border:'none', borderRadius:8, padding:'9px 20px', fontSize:14, fontWeight:600, cursor:'pointer' }}>Create User</button>
        </form>
      </div>

      <div style={{ background:'white', borderRadius:12, border:'1px solid #e2e8f0', overflow:'hidden' }}>
        <table style={{ width:'100%', borderCollapse:'collapse', fontSize:14 }}>
          <thead>
            <tr style={{ background:'#f8fafc', borderBottom:'1px solid #e2e8f0' }}>
              {['Name','Email','Role','Status','Last Login','Action'].map(h => (
                <th key={h} style={{ padding:'12px 16px', textAlign:'left', fontWeight:600, fontSize:13, color:'#374151' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u.id} style={{ borderBottom:'1px solid #f1f5f9' }}>
                <td style={{ padding:'12px 16px', fontWeight:500 }}>{u.name}</td>
                <td style={{ padding:'12px 16px', color:'#64748b' }}>{u.email}</td>
                <td style={{ padding:'12px 16px' }}>
                  <span style={{ background:roleColors[u.role]||'#f1f5f9', color:roleText[u.role]||'#374151', padding:'3px 10px', borderRadius:20, fontSize:12, fontWeight:500 }}>{u.role}</span>
                </td>
                <td style={{ padding:'12px 16px' }}>
                  <span style={{ background:u.is_active?'#dcfce7':'#fee2e2', color:u.is_active?'#166534':'#991b1b', padding:'3px 10px', borderRadius:20, fontSize:12, fontWeight:500 }}>
                    {u.is_active ? 'Active' : 'Disabled'}
                  </span>
                </td>
                <td style={{ padding:'12px 16px', color:'#94a3b8', fontSize:12 }}>
                  {u.last_login ? new Date(u.last_login).toLocaleDateString('en-IN') : 'Never'}
                </td>
                <td style={{ padding:'12px 16px' }}>
                  <button onClick={() => toggleActive(u)} style={{
                    background: u.is_active ? '#fee2e2' : '#dcfce7',
                    color: u.is_active ? '#991b1b' : '#166534',
                    border:'none', borderRadius:6, padding:'5px 12px', fontSize:12, cursor:'pointer', fontWeight:500
                  }}>{u.is_active ? 'Disable' : 'Enable'}</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── App Root ─────────────────────────────────────────────
export default function AdminApp() {
  const [token, setToken] = useState(() => localStorage.getItem('admin_token'));
  const [user,  setUser]  = useState(() => { try { return JSON.parse(localStorage.getItem('admin_user')); } catch { return null; } });

  const logout = () => {
    localStorage.removeItem('admin_token');
    localStorage.removeItem('admin_user');
    setToken(null); setUser(null);
  };

  return (
    <AuthCtx.Provider value={{ token, setToken, user, setUser, logout }}>
      <BrowserRouter>
        {!token ? <AdminLogin /> : (
          <AdminLayout>
            <Routes>
              <Route path="/admin"          element={<Overview />} />
              <Route path="/admin/servers"  element={<ServerConfig />} />
              <Route path="/admin/alerts"   element={<div><h2>Alert Rules — coming soon</h2></div>} />
              <Route path="/admin/scaling"  element={<ScalingConfig />} />
              <Route path="/admin/users"    element={<Users />} />
              <Route path="/admin/settings" element={<div><h2>Settings — env file se manage karo</h2><p style={{color:'#64748b'}}>Backend .env file mein ALERT_EMAIL, thresholds etc change karo aur server restart karo.</p></div>} />
              <Route path="*"               element={<Navigate to="/admin" />} />
            </Routes>
          </AdminLayout>
        )}
      </BrowserRouter>
    </AuthCtx.Provider>
  );
}
