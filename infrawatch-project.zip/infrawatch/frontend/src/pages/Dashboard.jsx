// FILE: /home/infrawatch/frontend/src/pages/Dashboard.jsx
import React, { useEffect, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import api from '../api/axios';
import toast from 'react-hot-toast';

const StatCard = ({ label, value, sub, color = '#0d9488' }) => (
  <div style={{
    background: 'white', borderRadius: 12, padding: '20px 24px',
    border: '1px solid #e2e8f0', flex: 1
  }}>
    <div style={{ fontSize: 13, color: '#64748b', marginBottom: 6 }}>{label}</div>
    <div style={{ fontSize: 30, fontWeight: 700, color }}>{value}</div>
    {sub && <div style={{ fontSize: 12, color: '#94a3b8', marginTop: 4 }}>{sub}</div>}
  </div>
);

export default function Dashboard() {
  const [summary, setSummary]   = useState([]);
  const [alerts, setAlerts]     = useState([]);
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [sumRes, alertRes] = await Promise.all([
          api.get('/api/metrics/summary'),
          api.get('/api/alerts/active'),
        ]);
        setSummary(sumRes.data.summary || []);
        setAlerts(alertRes.data.alerts || []);
      } catch (err) {
        toast.error('Failed to load dashboard data');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
    const interval = setInterval(fetchData, 30000); // 30 sec auto-refresh
    return () => clearInterval(interval);
  }, []);

  const healthy  = summary.filter(s => s.health === 'healthy').length;
  const warning  = summary.filter(s => s.health === 'warning').length;
  const critical = summary.filter(s => s.health === 'critical').length;

  if (loading) return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: 300 }}>
      <div style={{ color: '#64748b', fontSize: 15 }}>Loading dashboard...</div>
    </div>
  );

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: '#0f172a' }}>Dashboard</h1>
        <p style={{ margin: '4px 0 0', color: '#64748b', fontSize: 14 }}>
          Real-time AWS infrastructure overview · Auto-refreshes every 30s
        </p>
      </div>

      {/* Stat Cards */}
      <div style={{ display: 'flex', gap: 16, marginBottom: 24, flexWrap: 'wrap' }}>
        <StatCard label="Total Servers"   value={summary.length} sub="monitored instances" />
        <StatCard label="Healthy"         value={healthy}  color="#22c55e" sub="running normally" />
        <StatCard label="Warning"         value={warning}  color="#f59e0b" sub="needs attention" />
        <StatCard label="Active Alerts"   value={alerts.length} color={alerts.length > 0 ? '#ef4444' : '#22c55e'} sub="unresolved" />
      </div>

      {/* Server Status Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px,1fr))', gap: 16, marginBottom: 24 }}>
        {summary.map(server => (
          <div key={server.server_id} style={{
            background: 'white', borderRadius: 12, padding: 20,
            border: `1px solid ${server.health === 'critical' ? '#fca5a5' : server.health === 'warning' ? '#fde68a' : '#e2e8f0'}`
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 15, color: '#0f172a' }}>{server.name}</div>
                <div style={{ fontSize: 12, color: '#94a3b8', marginTop: 2 }}>{server.instance_id}</div>
              </div>
              <span style={{
                fontSize: 11, padding: '3px 8px', borderRadius: 20, fontWeight: 500,
                background: server.health === 'healthy' ? '#dcfce7' : server.health === 'warning' ? '#fef9c3' : '#fee2e2',
                color:      server.health === 'healthy' ? '#166534' : server.health === 'warning' ? '#92400e' : '#991b1b',
              }}>{server.health}</span>
            </div>
            {server.latest_metrics && (
              <div style={{ display: 'flex', gap: 16, marginTop: 8 }}>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 11, color: '#94a3b8', marginBottom: 4 }}>CPU</div>
                  <div style={{ height: 6, background: '#f1f5f9', borderRadius: 3 }}>
                    <div style={{
                      height: '100%', borderRadius: 3,
                      width: `${Math.min(server.latest_metrics.cpu_usage || 0, 100)}%`,
                      background: (server.latest_metrics.cpu_usage || 0) > 80 ? '#ef4444' : '#0d9488',
                    }} />
                  </div>
                  <div style={{ fontSize: 12, fontWeight: 600, marginTop: 3, color: '#374151' }}>
                    {(server.latest_metrics.cpu_usage || 0).toFixed(1)}%
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
        {summary.length === 0 && (
          <div style={{ gridColumn: '1/-1', textAlign: 'center', padding: 40, color: '#94a3b8' }}>
            No servers found. Add EC2 instances via the Servers page.
          </div>
        )}
      </div>

      {/* Recent Alerts */}
      {alerts.length > 0 && (
        <div style={{ background: 'white', borderRadius: 12, border: '1px solid #fca5a5', overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '1px solid #fee2e2', background: '#fff1f2' }}>
            <span style={{ fontWeight: 600, color: '#991b1b', fontSize: 14 }}>
              Active Alerts ({alerts.length})
            </span>
          </div>
          {alerts.slice(0, 5).map(alert => (
            <div key={alert.id} style={{
              padding: '14px 20px', borderBottom: '1px solid #f1f5f9',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center'
            }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 500, color: '#0f172a' }}>{alert.message}</div>
                <div style={{ fontSize: 12, color: '#94a3b8', marginTop: 2 }}>
                  {alert.server?.name} · {new Date(alert.createdAt).toLocaleString()}
                </div>
              </div>
              <span style={{
                fontSize: 11, padding: '3px 8px', borderRadius: 20, fontWeight: 600,
                background: alert.severity === 'critical' ? '#fee2e2' : '#fef9c3',
                color:      alert.severity === 'critical' ? '#991b1b' : '#92400e',
              }}>{alert.severity}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
