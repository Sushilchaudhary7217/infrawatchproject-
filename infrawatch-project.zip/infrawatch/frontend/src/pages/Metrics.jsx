// FILE: /home/infrawatch/frontend/src/pages/Metrics.jsx
import React, { useEffect, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import api from '../api/axios';
import toast from 'react-hot-toast';
import { format } from 'date-fns';

export default function Metrics() {
  const [servers,  setServers]  = useState([]);
  const [selected, setSelected] = useState('');
  const [metrics,  setMetrics]  = useState([]);
  const [hours,    setHours]    = useState(24);
  const [loading,  setLoading]  = useState(false);

  useEffect(() => {
    api.get('/api/servers').then(r => {
      const list = r.data.servers || [];
      setServers(list);
      if (list.length > 0) setSelected(list[0].id);
    }).catch(() => toast.error('Failed to load servers'));
  }, []);

  useEffect(() => {
    if (!selected) return;
    setLoading(true);
    api.get(`/api/servers/${selected}/metrics?hours=${hours}`)
      .then(r => setMetrics(r.data.metrics || []))
      .catch(() => toast.error('Failed to load metrics'))
      .finally(() => setLoading(false));
  }, [selected, hours]);

  const chartData = metrics.map(m => ({
    time: format(new Date(m.collected_at), 'HH:mm'),
    cpu:  parseFloat((m.cpu_usage || 0).toFixed(1)),
  }));

  const currentServer = servers.find(s => s.id === selected);
  const avgCpu = chartData.length > 0
    ? (chartData.reduce((a, b) => a + b.cpu, 0) / chartData.length).toFixed(1)
    : 0;
  const maxCpu = chartData.length > 0
    ? Math.max(...chartData.map(d => d.cpu)).toFixed(1)
    : 0;

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>Metrics</h1>
        <p style={{ margin: '4px 0 0', color: '#64748b', fontSize: 14 }}>CPU usage history from CloudWatch</p>
      </div>

      {/* Controls */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
        <select value={selected} onChange={e => setSelected(e.target.value)}
          style={{ padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 14, background: 'white', minWidth: 200 }}>
          {servers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
        {[6, 12, 24, 48].map(h => (
          <button key={h} onClick={() => setHours(h)} style={{
            padding: '8px 16px', borderRadius: 8, fontSize: 13, fontWeight: 500, cursor: 'pointer',
            background: hours === h ? '#0d9488' : '#f1f5f9',
            color: hours === h ? 'white' : '#374151',
            border: hours === h ? 'none' : '1px solid #e2e8f0'
          }}>{h}h</button>
        ))}
      </div>

      {/* Summary cards */}
      <div style={{ display: 'flex', gap: 16, marginBottom: 20 }}>
        {[
          { label: 'Avg CPU', value: `${avgCpu}%`, color: '#0d9488' },
          { label: 'Peak CPU', value: `${maxCpu}%`, color: parseFloat(maxCpu) > 80 ? '#ef4444' : '#f59e0b' },
          { label: 'Data Points', value: chartData.length, color: '#374151' },
          { label: 'Threshold', value: `${currentServer?.cpu_threshold || 70}%`, color: '#7c3aed' },
        ].map(card => (
          <div key={card.label} style={{ flex: 1, background: 'white', borderRadius: 12, padding: '16px 20px', border: '1px solid #e2e8f0' }}>
            <div style={{ fontSize: 12, color: '#94a3b8', marginBottom: 6 }}>{card.label}</div>
            <div style={{ fontSize: 26, fontWeight: 700, color: card.color }}>{card.value}</div>
          </div>
        ))}
      </div>

      {/* Chart */}
      <div style={{ background: 'white', borderRadius: 12, border: '1px solid #e2e8f0', padding: 24 }}>
        <div style={{ fontWeight: 600, marginBottom: 16, fontSize: 15, color: '#0f172a' }}>
          CPU Usage — Last {hours}h
        </div>
        {loading ? (
          <div style={{ height: 280, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8' }}>
            Loading metrics...
          </div>
        ) : chartData.length === 0 ? (
          <div style={{ height: 280, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8' }}>
            No metric data yet. Data collects every 5 minutes.
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={280}>
            <LineChart data={chartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="time" tick={{ fontSize: 11, fill: '#94a3b8' }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#94a3b8' }} unit="%" />
              <Tooltip formatter={(v) => [`${v}%`, 'CPU']} />
              <ReferenceLine y={currentServer?.cpu_threshold || 70} stroke="#ef4444" strokeDasharray="4 4" label={{ value: 'Threshold', position: 'right', fill: '#ef4444', fontSize: 11 }} />
              <Line type="monotone" dataKey="cpu" stroke="#0d9488" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}
