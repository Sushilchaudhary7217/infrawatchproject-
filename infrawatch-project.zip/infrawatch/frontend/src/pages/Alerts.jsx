// FILE: /home/infrawatch/frontend/src/pages/Alerts.jsx
import React, { useEffect, useState } from 'react';
import api from '../api/axios';
import toast from 'react-hot-toast';

export default function Alerts() {
  const [alerts, setAlerts] = useState([]);
  const [filter, setFilter] = useState('active');
  const [loading, setLoading] = useState(true);

  const fetchAlerts = async () => {
    setLoading(true);
    try {
      const { data } = await api.get(`/api/alerts?status=${filter}&limit=100`);
      setAlerts(data.alerts || []);
    } catch { toast.error('Failed to load alerts'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchAlerts(); }, [filter]);

  const handleAck = async (id) => {
    try {
      await api.put(`/api/alerts/${id}/acknowledge`);
      toast.success('Alert acknowledged');
      fetchAlerts();
    } catch { toast.error('Failed'); }
  };

  const handleResolve = async (id) => {
    try {
      await api.put(`/api/alerts/${id}/resolve`);
      toast.success('Alert resolved');
      fetchAlerts();
    } catch { toast.error('Failed'); }
  };

  const severityColor = (s) => s === 'critical' ? { bg: '#fee2e2', text: '#991b1b' } : s === 'warning' ? { bg: '#fef9c3', text: '#92400e' } : { bg: '#dbeafe', text: '#1e40af' };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>Alerts</h1>
          <p style={{ margin: '4px 0 0', color: '#64748b', fontSize: 14 }}>CloudWatch alarm history</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {['active','acknowledged','resolved'].map(s => (
            <button key={s} onClick={() => setFilter(s)} style={{
              padding: '7px 14px', borderRadius: 8, fontSize: 13, fontWeight: 500, cursor: 'pointer',
              background: filter === s ? '#0d9488' : '#f1f5f9',
              color: filter === s ? 'white' : '#374151',
              border: filter === s ? 'none' : '1px solid #e2e8f0'
            }}>{s.charAt(0).toUpperCase() + s.slice(1)}</button>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: 40, color: '#94a3b8' }}>Loading...</div>
        ) : alerts.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 60, color: '#94a3b8', background: 'white', borderRadius: 12, border: '1px solid #e2e8f0' }}>
            No {filter} alerts
          </div>
        ) : alerts.map(alert => {
          const col = severityColor(alert.severity);
          return (
            <div key={alert.id} style={{ background: 'white', borderRadius: 12, padding: 20, border: `1px solid ${col.bg}`, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 16 }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 6 }}>
                  <span style={{ background: col.bg, color: col.text, fontSize: 11, padding: '2px 8px', borderRadius: 20, fontWeight: 600 }}>{alert.severity}</span>
                  <span style={{ background: '#f1f5f9', color: '#374151', fontSize: 11, padding: '2px 8px', borderRadius: 20 }}>{alert.type}</span>
                </div>
                <p style={{ margin: '0 0 6px', fontSize: 14, fontWeight: 500, color: '#0f172a' }}>{alert.message}</p>
                <div style={{ fontSize: 12, color: '#94a3b8' }}>
                  {alert.server?.name} · {new Date(alert.createdAt).toLocaleString('en-IN')}
                  {alert.value && ` · Value: ${alert.value.toFixed(1)}%`}
                </div>
              </div>
              {alert.status === 'active' && (
                <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
                  <button onClick={() => handleAck(alert.id)} style={{ background: '#fef9c3', color: '#92400e', border: 'none', borderRadius: 6, padding: '6px 12px', fontSize: 12, cursor: 'pointer', fontWeight: 500 }}>Acknowledge</button>
                  <button onClick={() => handleResolve(alert.id)} style={{ background: '#dcfce7', color: '#166534', border: 'none', borderRadius: 6, padding: '6px 12px', fontSize: 12, cursor: 'pointer', fontWeight: 500 }}>Resolve</button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// FILE: /home/infrawatch/frontend/src/pages/Metrics.jsx
// (Placeholder - recharts CPU graph)
