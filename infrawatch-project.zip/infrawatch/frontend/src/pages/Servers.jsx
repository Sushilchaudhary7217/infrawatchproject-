// FILE: /home/infrawatch/frontend/src/pages/Servers.jsx
import React, { useEffect, useState } from 'react';
import api from '../api/axios';
import toast from 'react-hot-toast';

export default function Servers() {
  const [servers, setServers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm] = useState({ name: '', instance_id: '', instance_type: 't2.micro', cpu_threshold: 70, memory_threshold: 80, disk_threshold: 85 });

  const fetchServers = async () => {
    try {
      const { data } = await api.get('/api/servers');
      setServers(data.servers || []);
    } catch { toast.error('Failed to load servers'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchServers(); }, []);

  const handleAdd = async (e) => {
    e.preventDefault();
    try {
      await api.post('/api/servers', form);
      toast.success('Server added!');
      setShowAdd(false);
      fetchServers();
    } catch (err) { toast.error(err.response?.data?.error || 'Failed'); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Remove this server?')) return;
    try {
      await api.delete(`/api/servers/${id}`);
      toast.success('Server removed');
      fetchServers();
    } catch { toast.error('Failed to remove'); }
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div>
          <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700 }}>Servers</h1>
          <p style={{ margin: '4px 0 0', color: '#64748b', fontSize: 14 }}>Manage EC2 instances</p>
        </div>
        <button onClick={() => setShowAdd(!showAdd)} style={{
          background: '#0d9488', color: 'white', border: 'none', borderRadius: 8,
          padding: '9px 18px', fontSize: 14, fontWeight: 600, cursor: 'pointer'
        }}>+ Add Server</button>
      </div>

      {showAdd && (
        <div style={{ background: 'white', borderRadius: 12, padding: 24, border: '1px solid #e2e8f0', marginBottom: 20 }}>
          <h3 style={{ margin: '0 0 16px', fontSize: 16 }}>Add New Server</h3>
          <form onSubmit={handleAdd}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
              {[
                ['Server Name',    'name',         'text',   'e.g. Web Server 1'],
                ['EC2 Instance ID','instance_id',  'text',   'i-0abc123def456'],
              ].map(([label, key, type, ph]) => (
                <div key={key}>
                  <label style={{ fontSize: 13, fontWeight: 500, display: 'block', marginBottom: 4 }}>{label}</label>
                  <input type={type} placeholder={ph} value={form[key]}
                    onChange={e => setForm({...form, [key]: e.target.value})}
                    style={{ width: '100%', padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 14, boxSizing: 'border-box' }}
                  />
                </div>
              ))}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginBottom: 16 }}>
              {[
                ['CPU Threshold %',    'cpu_threshold',    70],
                ['Memory Threshold %', 'memory_threshold', 80],
                ['Disk Threshold %',   'disk_threshold',   85],
              ].map(([label, key, def]) => (
                <div key={key}>
                  <label style={{ fontSize: 13, fontWeight: 500, display: 'block', marginBottom: 4 }}>{label}</label>
                  <input type="number" min={10} max={99} value={form[key]}
                    onChange={e => setForm({...form, [key]: parseInt(e.target.value)})}
                    style={{ width: '100%', padding: '8px 12px', border: '1px solid #d1d5db', borderRadius: 8, fontSize: 14, boxSizing: 'border-box' }}
                  />
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button type="submit" style={{ background: '#0d9488', color: 'white', border: 'none', borderRadius: 8, padding: '9px 20px', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>Add Server</button>
              <button type="button" onClick={() => setShowAdd(false)} style={{ background: '#f1f5f9', color: '#374151', border: '1px solid #e2e8f0', borderRadius: 8, padding: '9px 20px', fontSize: 14, cursor: 'pointer' }}>Cancel</button>
            </div>
          </form>
        </div>
      )}

      <div style={{ background: 'white', borderRadius: 12, border: '1px solid #e2e8f0', overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 14 }}>
          <thead>
            <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
              {['Name','Instance ID','Type','Status','Health','CPU%','Actions'].map(h => (
                <th key={h} style={{ padding: '12px 16px', textAlign: 'left', fontWeight: 600, color: '#374151', fontSize: 13 }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={7} style={{ padding: 40, textAlign: 'center', color: '#94a3b8' }}>Loading...</td></tr>
            ) : servers.length === 0 ? (
              <tr><td colSpan={7} style={{ padding: 40, textAlign: 'center', color: '#94a3b8' }}>No servers yet. Click "Add Server" to begin.</td></tr>
            ) : servers.map(s => (
              <tr key={s.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                <td style={{ padding: '12px 16px', fontWeight: 500 }}>{s.name}</td>
                <td style={{ padding: '12px 16px', fontFamily: 'monospace', fontSize: 13, color: '#0d9488' }}>{s.instance_id || '—'}</td>
                <td style={{ padding: '12px 16px', color: '#64748b' }}>{s.instance_type}</td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{
                    background: s.status === 'running' ? '#dcfce7' : '#fee2e2',
                    color: s.status === 'running' ? '#166534' : '#991b1b',
                    padding: '2px 8px', borderRadius: 20, fontSize: 12, fontWeight: 500
                  }}>{s.status}</span>
                </td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{
                    background: s.health === 'healthy' ? '#dcfce7' : s.health === 'warning' ? '#fef9c3' : '#fee2e2',
                    color: s.health === 'healthy' ? '#166534' : s.health === 'warning' ? '#92400e' : '#991b1b',
                    padding: '2px 8px', borderRadius: 20, fontSize: 12, fontWeight: 500
                  }}>{s.health}</span>
                </td>
                <td style={{ padding: '12px 16px', color: '#374151' }}>{s.cpu_threshold}%</td>
                <td style={{ padding: '12px 16px' }}>
                  <button onClick={() => handleDelete(s.id)} style={{
                    background: '#fee2e2', color: '#991b1b', border: 'none', borderRadius: 6,
                    padding: '5px 12px', fontSize: 12, cursor: 'pointer', fontWeight: 500
                  }}>Remove</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
