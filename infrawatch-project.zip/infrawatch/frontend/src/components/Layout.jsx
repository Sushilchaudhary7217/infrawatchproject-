// FILE: /home/infrawatch/frontend/src/components/Layout.jsx
import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../api/AuthContext';

const navItems = [
  { path: '/',        label: 'Dashboard',  icon: '▦' },
  { path: '/servers', label: 'Servers',    icon: '⬛' },
  { path: '/alerts',  label: 'Alerts',     icon: '🔔' },
  { path: '/metrics', label: 'Metrics',    icon: '📈' },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: '#f1f5f9' }}>
      {/* Sidebar */}
      <aside style={{
        width: sidebarOpen ? 240 : 64, transition: 'width 0.2s',
        background: '#0f172a', display: 'flex', flexDirection: 'column',
        position: 'sticky', top: 0, height: '100vh'
      }}>
        {/* Logo */}
        <div style={{ padding: '20px 16px', borderBottom: '1px solid #1e293b' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{
              width: 32, height: 32, background: '#0d9488', borderRadius: 8,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: 'white', fontWeight: 700, fontSize: 14, flexShrink: 0
            }}>IW</div>
            {sidebarOpen && <span style={{ color: 'white', fontWeight: 600, fontSize: 15 }}>InfraWatch</span>}
          </div>
        </div>

        {/* Nav Links */}
        <nav style={{ flex: 1, padding: '12px 8px' }}>
          {navItems.map(item => (
            <NavLink key={item.path} to={item.path} end={item.path === '/'}
              style={({ isActive }) => ({
                display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px',
                borderRadius: 8, marginBottom: 4, textDecoration: 'none',
                color: isActive ? 'white' : '#94a3b8',
                background: isActive ? '#0d9488' : 'transparent',
                fontSize: 14, fontWeight: isActive ? 600 : 400,
                transition: 'all 0.15s'
              })}>
              <span style={{ fontSize: 16 }}>{item.icon}</span>
              {sidebarOpen && item.label}
            </NavLink>
          ))}
        </nav>

        {/* User + Logout */}
        <div style={{ padding: '12px 8px', borderTop: '1px solid #1e293b' }}>
          {sidebarOpen && (
            <div style={{ padding: '8px 12px', marginBottom: 8 }}>
              <div style={{ color: 'white', fontSize: 13, fontWeight: 500 }}>{user?.name}</div>
              <div style={{ color: '#64748b', fontSize: 11 }}>{user?.role}</div>
            </div>
          )}
          <button onClick={logout} style={{
            width: '100%', padding: '8px 12px', background: 'transparent',
            border: '1px solid #1e293b', borderRadius: 8, color: '#94a3b8',
            cursor: 'pointer', fontSize: 13, textAlign: 'left',
            display: 'flex', alignItems: 'center', gap: 8
          }}>
            <span>↩</span>{sidebarOpen && 'Logout'}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main style={{ flex: 1, overflow: 'auto' }}>
        {/* Top bar */}
        <header style={{
          background: 'white', borderBottom: '1px solid #e2e8f0',
          padding: '14px 24px', display: 'flex', alignItems: 'center',
          justifyContent: 'space-between', position: 'sticky', top: 0, zIndex: 10
        }}>
          <button onClick={() => setSidebarOpen(!sidebarOpen)} style={{
            background: 'none', border: 'none', cursor: 'pointer', fontSize: 20, color: '#64748b'
          }}>☰</button>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ fontSize: 12, color: '#64748b' }}>Region: ap-south-1</span>
            <div style={{
              width: 8, height: 8, borderRadius: '50%', background: '#22c55e',
              boxShadow: '0 0 6px #22c55e'
            }} title="Connected" />
          </div>
        </header>

        <div style={{ padding: 24 }}>
          <Outlet />
        </div>
      </main>
    </div>
  );
}
