// FILE: /home/infrawatch/frontend/src/api/axios.js
import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:3001',
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

// Har request ke saath JWT token attach karo
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('infrawatch_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// 401 pe automatically logout karo
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('infrawatch_token');
      localStorage.removeItem('infrawatch_user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;
