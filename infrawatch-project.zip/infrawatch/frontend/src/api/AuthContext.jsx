// FILE: /home/infrawatch/frontend/src/api/AuthContext.jsx
import React, { createContext, useContext, useState, useCallback } from 'react';
import api from './axios';
import toast from 'react-hot-toast';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('infrawatch_token'));
  const [user,  setUser]  = useState(() => {
    try { return JSON.parse(localStorage.getItem('infrawatch_user')); } catch { return null; }
  });

  const login = useCallback(async (email, password) => {
    const { data } = await api.post('/api/auth/login', { email, password });
    localStorage.setItem('infrawatch_token', data.token);
    localStorage.setItem('infrawatch_user', JSON.stringify(data.user));
    setToken(data.token);
    setUser(data.user);
    return data.user;
  }, []);

  const logout = useCallback(async () => {
    try { await api.post('/api/auth/logout'); } catch {}
    localStorage.removeItem('infrawatch_token');
    localStorage.removeItem('infrawatch_user');
    setToken(null);
    setUser(null);
    window.location.href = '/login';
  }, []);

  return (
    <AuthContext.Provider value={{ token, user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
