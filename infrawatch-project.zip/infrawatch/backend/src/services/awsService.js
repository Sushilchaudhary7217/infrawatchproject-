// ============================================================
// FILE: /home/infrawatch/backend/src/services/awsService.js
// PURPOSE: Sabhi AWS API calls yahan hain - EC2, CloudWatch, SNS, ASG
// ============================================================

const { EC2Client, DescribeInstancesCommand, TerminateInstancesCommand } = require('@aws-sdk/client-ec2');
const { CloudWatchClient, GetMetricStatisticsCommand, PutMetricAlarmCommand } = require('@aws-sdk/client-cloudwatch');
const { AutoScalingClient, DescribeAutoScalingGroupsCommand, UpdateAutoScalingGroupCommand, SetDesiredCapacityCommand } = require('@aws-sdk/client-auto-scaling');
const { SNSClient, PublishCommand, CreateTopicCommand, SubscribeCommand } = require('@aws-sdk/client-sns');

const awsConfig = {
  region: process.env.AWS_REGION || 'ap-south-1',
  credentials: {
    accessKeyId:     process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
};

const ec2Client   = new EC2Client(awsConfig);
const cwClient    = new CloudWatchClient(awsConfig);
const asgClient   = new AutoScalingClient(awsConfig);
const snsClient   = new SNSClient(awsConfig);

// ── EC2 Functions ─────────────────────────────────────────

async function getEC2Details(instanceId) {
  const cmd = new DescribeInstancesCommand({ InstanceIds: [instanceId] });
  const response = await ec2Client.send(cmd);
  const instance = response.Reservations?.[0]?.Instances?.[0];
  if (!instance) throw new Error(`Instance ${instanceId} not found`);
  return {
    instance_id:   instance.InstanceId,
    state:         instance.State.Name,
    instance_type: instance.InstanceType,
    public_ip:     instance.PublicIpAddress,
    private_ip:    instance.PrivateIpAddress,
    launch_time:   instance.LaunchTime,
    tags:          instance.Tags,
  };
}

async function terminateInstance(instanceId) {
  const cmd = new TerminateInstancesCommand({ InstanceIds: [instanceId] });
  return ec2Client.send(cmd);
}

// ── CloudWatch Functions ──────────────────────────────────

async function getCloudWatchMetrics(instanceId, metricName = 'CPUUtilization', hours = 1) {
  const endTime = new Date();
  const startTime = new Date(endTime - hours * 3600 * 1000);

  const cmd = new GetMetricStatisticsCommand({
    Namespace:  'AWS/EC2',
    MetricName: metricName,
    Dimensions: [{ Name: 'InstanceId', Value: instanceId }],
    StartTime:  startTime,
    EndTime:    endTime,
    Period:     300,  // 5 min intervals
    Statistics: ['Average', 'Maximum'],
  });

  const response = await cwClient.send(cmd);
  return response.Datapoints.sort((a, b) => new Date(a.Timestamp) - new Date(b.Timestamp));
}

async function createCloudWatchAlarm(instanceId, alarmName, metricName, threshold, snsTopicArn) {
  const cmd = new PutMetricAlarmCommand({
    AlarmName:          alarmName,
    AlarmDescription:   `InfraWatch: ${metricName} alarm for ${instanceId}`,
    ActionsEnabled:     true,
    AlarmActions:       [snsTopicArn],
    OKActions:          [snsTopicArn],
    MetricName:         metricName,
    Namespace:          'AWS/EC2',
    Dimensions:         [{ Name: 'InstanceId', Value: instanceId }],
    Period:             parseInt(process.env.ALARM_PERIOD_SECONDS) || 60,
    EvaluationPeriods:  parseInt(process.env.ALARM_EVALUATION_PERIODS) || 2,
    Threshold:          threshold,
    ComparisonOperator: 'GreaterThanOrEqualToThreshold',
    Statistic:          'Average',
    TreatMissingData:   'notBreaching',
  });
  return cwClient.send(cmd);
}

// ── Auto Scaling Functions ────────────────────────────────

async function getASGDetails(asgName) {
  const cmd = new DescribeAutoScalingGroupsCommand({ AutoScalingGroupNames: [asgName] });
  const response = await asgClient.send(cmd);
  return response.AutoScalingGroups?.[0];
}

async function updateASGConfig(asgName, { min_size, max_size, desired_capacity }) {
  const cmd = new UpdateAutoScalingGroupCommand({
    AutoScalingGroupName: asgName,
    MinSize:     parseInt(min_size),
    MaxSize:     parseInt(max_size),
    DesiredCapacity: parseInt(desired_capacity),
  });
  return asgClient.send(cmd);
}

async function triggerScaleOut(asgName, count = 1) {
  const current = await getASGDetails(asgName);
  const newDesired = (current?.DesiredCapacity || 1) + count;
  const cmd = new SetDesiredCapacityCommand({
    AutoScalingGroupName: asgName,
    DesiredCapacity: newDesired,
    HonorCooldown: false,
  });
  return asgClient.send(cmd);
}

async function triggerScaleIn(asgName, count = 1) {
  const current = await getASGDetails(asgName);
  const newDesired = Math.max(1, (current?.DesiredCapacity || 1) - count);
  const cmd = new SetDesiredCapacityCommand({
    AutoScalingGroupName: asgName,
    DesiredCapacity: newDesired,
    HonorCooldown: false,
  });
  return asgClient.send(cmd);
}

// ── SNS Functions ─────────────────────────────────────────

async function sendSNSNotification(message, subject = 'InfraWatch Alert') {
  const cmd = new PublishCommand({
    TopicArn: process.env.SNS_TOPIC_ARN,
    Message:  message,
    Subject:  `[InfraWatch] ${subject}`,
  });
  return snsClient.send(cmd);
}

async function setupSNSTopic(email) {
  const create = new CreateTopicCommand({ Name: 'InfraWatchAlerts' });
  const topic = await snsClient.send(create);

  const subscribe = new SubscribeCommand({
    TopicArn: topic.TopicArn,
    Protocol: 'email',
    Endpoint: email,
  });
  await snsClient.send(subscribe);
  return topic.TopicArn;
}

module.exports = {
  getEC2Details, terminateInstance,
  getCloudWatchMetrics, createCloudWatchAlarm,
  getASGDetails, updateASGConfig, triggerScaleOut, triggerScaleIn,
  sendSNSNotification, setupSNSTopic,
};
