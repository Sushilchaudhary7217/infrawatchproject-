// ============================================================
// FILE: /home/infrawatch/backend/src/services/metricsCollector.js
// PURPOSE: Har 5 minute mein AWS se metrics collect karta hai automatically
// ============================================================
const cron = require('node-cron');
const { Server, Metric, Alert } = require('../models');
const { getCloudWatchMetrics } = require('./awsService');
const { sendSNSNotification } = require('./snsService');

async function collectMetricsForServer(server) {
  try {
    const cpuData  = await getCloudWatchMetrics(server.instance_id, 'CPUUtilization', 0.2);
    const latest   = cpuData[cpuData.length - 1];
    if (!latest) return;

    const cpuValue = parseFloat(latest.Average.toFixed(2));

    await Metric.create({
      server_id:   server.id,
      cpu_usage:   cpuValue,
      collected_at: new Date(),
    });

    // Threshold check karo
    let health = 'healthy';
    if (cpuValue >= server.cpu_threshold) {
      health = cpuValue >= 90 ? 'critical' : 'warning';

      // Alert banao agar already active nahi hai
      const existing = await Alert.findOne({
        where: { server_id: server.id, type: 'cpu', status: 'active' },
      });

      if (!existing) {
        await Alert.create({
          server_id: server.id,
          type: 'cpu',
          severity: health,
          message: `CPU usage ${cpuValue}% exceeded threshold ${server.cpu_threshold}%`,
          value: cpuValue,
          threshold: server.cpu_threshold,
        });

        // Email notification
        await sendSNSNotification(
          `ALERT: Server "${server.name}" (${server.instance_id})\nCPU: ${cpuValue}%\nThreshold: ${server.cpu_threshold}%\nTime: ${new Date().toISOString()}`,
          `${health.toUpperCase()} - CPU Alert`
        ).catch(console.error);
      }
    } else {
      // CPU normal hai - resolve pending cpu alerts
      await Alert.update(
        { status: 'resolved', resolved_at: new Date() },
        { where: { server_id: server.id, type: 'cpu', status: 'active' } }
      );
    }

    await server.update({ health, last_seen: new Date() });
  } catch (err) {
    console.error(`Metrics collection failed for ${server.instance_id}:`, err.message);
  }
}

function startMetricsCollector() {
  // Har 5 minute mein chalao
  cron.schedule('*/5 * * * *', async () => {
    console.log('[Metrics] Collecting from AWS CloudWatch...');
    const servers = await Server.findAll({ where: { status: 'running' } });
    for (const server of servers) {
      await collectMetricsForServer(server);
    }
    console.log(`[Metrics] Done. Collected for ${servers.length} servers.`);
  });
  console.log('✅ Metrics collector started (every 5 min)');
}

module.exports = { startMetricsCollector };

// ============================================================
// FILE: /home/infrawatch/backend/src/services/snsService.js
// ============================================================
const { SNSClient, PublishCommand } = require('@aws-sdk/client-sns');

const client = new SNSClient({
  region: process.env.AWS_REGION || 'ap-south-1',
  credentials: {
    accessKeyId:     process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

async function sendSNSNotification(message, subject = 'Alert') {
  if (!process.env.SNS_TOPIC_ARN || process.env.SNS_TOPIC_ARN.includes('123456789')) {
    console.log('[SNS] Skipping - SNS_TOPIC_ARN not configured');
    return;
  }
  const cmd = new PublishCommand({
    TopicArn: process.env.SNS_TOPIC_ARN,
    Message:  message,
    Subject:  `[InfraWatch] ${subject}`,
  });
  return client.send(cmd);
}

module.exports = { sendSNSNotification };

// ============================================================
// FILE: /home/infrawatch/backend/src/services/seedService.js
// PURPOSE: First run par default admin user banata hai
// ============================================================
const { User } = require('../models');

async function seedAdminUser() {
  try {
    const exists = await User.findOne({ where: { email: process.env.ADMIN_EMAIL } });
    if (!exists) {
      await User.create({
        name:     'Super Admin',
        email:    process.env.ADMIN_EMAIL    || 'admin@infrawatch.cloud',
        password: process.env.ADMIN_PASSWORD || 'Admin@123456',
        role:     'superadmin',
      });
      console.log(`✅ Admin user created: ${process.env.ADMIN_EMAIL}`);
    }
  } catch (err) {
    console.error('Seed failed:', err.message);
  }
}

module.exports = { seedAdminUser };
