// ============================================================
// FILE: /home/infrawatch/backend/src/routes/alerts.js
// ============================================================
const router = require('express').Router();
const { Alert, Server } = require('../models');
const { protect, authorize } = require('../middleware/authMiddleware');
const { sendSNSNotification } = require('../services/snsService');
const { Op } = require('sequelize');

// GET /api/alerts - all alerts with filters
router.get('/', protect, async (req, res) => {
  try {
    const { status, severity, server_id, limit = 50, page = 1 } = req.query;
    const where = {};
    if (status)    where.status = status;
    if (severity)  where.severity = severity;
    if (server_id) where.server_id = server_id;

    const { count, rows } = await Alert.findAndCountAll({
      where, include: [{ model: Server, as: 'server', attributes: ['name', 'instance_id'] }],
      order: [['createdAt', 'DESC']],
      limit: parseInt(limit), offset: (page - 1) * limit,
    });
    res.json({ success: true, total: count, page: parseInt(page), alerts: rows });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/alerts/active
router.get('/active', protect, async (req, res) => {
  try {
    const alerts = await Alert.findAll({
      where: { status: 'active' },
      include: [{ model: Server, as: 'server', attributes: ['name', 'public_ip'] }],
      order: [['createdAt', 'DESC']],
    });
    res.json({ success: true, count: alerts.length, alerts });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// PUT /api/alerts/:id/acknowledge
router.put('/:id/acknowledge', protect, async (req, res) => {
  try {
    const alert = await Alert.findByPk(req.params.id);
    if (!alert) return res.status(404).json({ error: 'Alert not found' });
    await alert.update({ status: 'acknowledged' });
    res.json({ success: true, message: 'Alert acknowledged', alert });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// PUT /api/alerts/:id/resolve
router.put('/:id/resolve', protect, authorize('superadmin','admin','operator'), async (req, res) => {
  try {
    const alert = await Alert.findByPk(req.params.id);
    if (!alert) return res.status(404).json({ error: 'Alert not found' });
    await alert.update({ status: 'resolved', resolved_at: new Date() });
    res.json({ success: true, message: 'Alert resolved', alert });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/alerts/test - test alert bhejo (admin panel se)
router.post('/test', protect, authorize('superadmin','admin'), async (req, res) => {
  try {
    const { email } = req.body;
    await sendSNSNotification('TEST ALERT - InfraWatch is working correctly!', 'test');
    res.json({ success: true, message: `Test alert sent to ${email || process.env.ALERT_EMAIL}` });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;

// ============================================================
// FILE: /home/infrawatch/backend/src/routes/metrics.js
// ============================================================
const metricsRouter = require('express').Router();
const { Metric, Server } = require('../models');
const { protect } = require('../middleware/authMiddleware');
const { getCloudWatchMetrics } = require('../services/awsService');
const { Op: Op2 } = require('sequelize');

// GET /api/metrics/summary - dashboard ke liye
metricsRouter.get('/summary', protect, async (req, res) => {
  try {
    const servers = await Server.findAll({ where: { status: 'running' } });
    const summary = [];
    for (const s of servers) {
      const latest = await Metric.findOne({ where: { server_id: s.id }, order: [['collected_at','DESC']] });
      summary.push({ server_id: s.id, name: s.name, instance_id: s.instance_id, health: s.health, latest_metrics: latest });
    }
    res.json({ success: true, summary });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/metrics/:serverId/cloudwatch - live AWS data
metricsRouter.get('/:serverId/cloudwatch', protect, async (req, res) => {
  try {
    const server = await Server.findByPk(req.params.serverId);
    if (!server) return res.status(404).json({ error: 'Server not found' });
    const data = await getCloudWatchMetrics(server.instance_id);
    res.json({ success: true, data });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = metricsRouter;
