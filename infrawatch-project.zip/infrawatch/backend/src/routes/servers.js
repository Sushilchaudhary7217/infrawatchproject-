// ============================================================
// FILE: /home/infrawatch/backend/src/routes/servers.js
// ============================================================
const router = require('express').Router();
const { Server, Alert, Metric } = require('../models');
const { protect, authorize } = require('../middleware/authMiddleware');
const { getEC2Details, terminateInstance } = require('../services/awsService');

// GET /api/servers - sabhi servers
router.get('/', protect, async (req, res) => {
  try {
    const servers = await Server.findAll({
      include: [{ model: Alert, as: 'alerts', where: { status: 'active' }, required: false, limit: 5 }],
      order: [['createdAt', 'DESC']],
    });
    res.json({ success: true, count: servers.length, servers });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/servers/:id - ek server detail
router.get('/:id', protect, async (req, res) => {
  try {
    const server = await Server.findByPk(req.params.id);
    if (!server) return res.status(404).json({ error: 'Server not found' });
    const awsData = await getEC2Details(server.instance_id).catch(() => null);
    res.json({ success: true, server, awsData });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/servers - naya server add (admin only)
router.post('/', protect, authorize('superadmin','admin'), async (req, res) => {
  try {
    const { name, instance_id, instance_type, region, cpu_threshold, memory_threshold, disk_threshold, tags } = req.body;
    const server = await Server.create({ name, instance_id, instance_type, region, cpu_threshold, memory_threshold, disk_threshold, tags });
    res.status(201).json({ success: true, server });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

// PUT /api/servers/:id - thresholds update karo (admin panel se yahi call hoga)
router.put('/:id', protect, authorize('superadmin','admin','operator'), async (req, res) => {
  try {
    const server = await Server.findByPk(req.params.id);
    if (!server) return res.status(404).json({ error: 'Server not found' });
    await server.update(req.body);
    res.json({ success: true, message: 'Server updated', server });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

// DELETE /api/servers/:id
router.delete('/:id', protect, authorize('superadmin'), async (req, res) => {
  try {
    const server = await Server.findByPk(req.params.id);
    if (!server) return res.status(404).json({ error: 'Server not found' });
    await server.destroy();
    res.json({ success: true, message: 'Server removed' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/servers/:id/metrics - last 24 hours metrics
router.get('/:id/metrics', protect, async (req, res) => {
  try {
    const { hours = 24 } = req.query;
    const since = new Date(Date.now() - hours * 3600 * 1000);
    const metrics = await Metric.findAll({
      where: { server_id: req.params.id, collected_at: { [require('sequelize').Op.gte]: since } },
      order: [['collected_at', 'DESC']], limit: 288,
    });
    res.json({ success: true, metrics });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
