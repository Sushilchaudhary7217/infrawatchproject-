// ============================================================
// FILE: /home/infrawatch/backend/src/routes/scaling.js
// ============================================================
const router = require('express').Router();
const { ScalingEvent, Server } = require('../models');
const { protect, authorize } = require('../middleware/authMiddleware');
const { triggerScaleOut, triggerScaleIn, getASGDetails, updateASGConfig } = require('../services/awsService');

// GET /api/scaling/history
router.get('/history', protect, async (req, res) => {
  try {
    const events = await ScalingEvent.findAll({ order: [['createdAt','DESC']], limit: 100 });
    res.json({ success: true, events });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/scaling/trigger - manual scale out
router.post('/trigger', protect, authorize('superadmin','admin','operator'), async (req, res) => {
  try {
    const { asg_name, action, count = 1 } = req.body;
    const result = action === 'scale_out'
      ? await triggerScaleOut(asg_name, count)
      : await triggerScaleIn(asg_name, count);
    await ScalingEvent.create({ asg_name, action, reason: `Manual trigger by ${req.user.email}`, triggered_by: 'manual', status: 'success' });
    res.json({ success: true, message: `${action} triggered`, result });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/scaling/asg/:name - ASG details
router.get('/asg/:name', protect, async (req, res) => {
  try {
    const details = await getASGDetails(req.params.name);
    res.json({ success: true, details });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// PUT /api/scaling/config - admin panel se min/max instances change
router.put('/config', protect, authorize('superadmin','admin'), async (req, res) => {
  try {
    const { asg_name, min_size, max_size, desired_capacity } = req.body;
    const result = await updateASGConfig(asg_name, { min_size, max_size, desired_capacity });
    res.json({ success: true, message: 'ASG config updated', result });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;

// ============================================================
// FILE: /home/infrawatch/backend/src/routes/admin.js
// PURPOSE: Admin panel specific routes - config change
// ============================================================
const adminRouter = require('express').Router();
const { User } = require('../models');
const { protect, authorize } = require('../middleware/authMiddleware');

// GET /api/admin/users
adminRouter.get('/users', protect, authorize('superadmin','admin'), async (req, res) => {
  try {
    const users = await User.findAll({ attributes: { exclude: ['password'] } });
    res.json({ success: true, users });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/admin/users - naya user banao
adminRouter.post('/users', protect, authorize('superadmin'), async (req, res) => {
  try {
    const { name, email, password, role } = req.body;
    const existing = await User.findOne({ where: { email } });
    if (existing) return res.status(400).json({ error: 'Email already exists' });
    const user = await User.create({ name, email, password, role });
    res.status(201).json({ success: true, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

// PUT /api/admin/users/:id - role change, deactivate
adminRouter.put('/users/:id', protect, authorize('superadmin'), async (req, res) => {
  try {
    const user = await User.findByPk(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    const { role, is_active, name } = req.body;
    await user.update({ role, is_active, name });
    res.json({ success: true, message: 'User updated' });
  } catch (err) { res.status(400).json({ error: err.message }); }
});

// DELETE /api/admin/users/:id
adminRouter.delete('/users/:id', protect, authorize('superadmin'), async (req, res) => {
  try {
    if (req.params.id === req.user.id) return res.status(400).json({ error: 'Cannot delete yourself' });
    await User.destroy({ where: { id: req.params.id } });
    res.json({ success: true, message: 'User deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/admin/settings - current system settings
adminRouter.get('/settings', protect, authorize('superadmin','admin'), (req, res) => {
  res.json({
    success: true,
    settings: {
      region: process.env.AWS_REGION,
      cpu_threshold: parseInt(process.env.CPU_ALARM_THRESHOLD),
      memory_threshold: parseInt(process.env.MEMORY_ALARM_THRESHOLD),
      disk_threshold: parseInt(process.env.DISK_ALARM_THRESHOLD),
      asg_min: parseInt(process.env.ASG_MIN_SIZE),
      asg_max: parseInt(process.env.ASG_MAX_SIZE),
      alert_email: process.env.ALERT_EMAIL,
    },
  });
});

module.exports = adminRouter;
