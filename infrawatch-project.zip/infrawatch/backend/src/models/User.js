// ============================================================
// FILE: /home/infrawatch/backend/src/models/User.js
// ============================================================
const { DataTypes } = require('sequelize');
const bcrypt = require('bcryptjs');

module.exports = (sequelize) => {
  const User = sequelize.define('User', {
    id:       { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
    name:     { type: DataTypes.STRING, allowNull: false },
    email:    { type: DataTypes.STRING, allowNull: false, unique: true, validate: { isEmail: true } },
    password: { type: DataTypes.STRING, allowNull: false },
    role:     { type: DataTypes.ENUM('superadmin', 'admin', 'operator', 'viewer'), defaultValue: 'viewer' },
    is_active: { type: DataTypes.BOOLEAN, defaultValue: true },
    last_login: { type: DataTypes.DATE },
  }, {
    tableName: 'users',
    hooks: {
      beforeCreate: async (user) => { user.password = await bcrypt.hash(user.password, 12); },
      beforeUpdate: async (user) => {
        if (user.changed('password')) { user.password = await bcrypt.hash(user.password, 12); }
      },
    },
  });
  User.prototype.validatePassword = async function(plain) {
    return bcrypt.compare(plain, this.password);
  };
  return User;
};
