// ============================================================
// FILE: /home/infrawatch/backend/src/models/Server.js
// ============================================================
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => sequelize.define('Server', {
  id:            { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  name:          { type: DataTypes.STRING, allowNull: false },
  instance_id:   { type: DataTypes.STRING, unique: true },  // AWS EC2 instance ID
  instance_type: { type: DataTypes.STRING, defaultValue: 't2.micro' },
  region:        { type: DataTypes.STRING, defaultValue: 'ap-south-1' },
  public_ip:     { type: DataTypes.STRING },
  private_ip:    { type: DataTypes.STRING },
  status:        { type: DataTypes.ENUM('running','stopped','terminated','pending','unknown'), defaultValue: 'unknown' },
  health:        { type: DataTypes.ENUM('healthy','warning','critical','unknown'), defaultValue: 'unknown' },
  cpu_threshold:    { type: DataTypes.INTEGER, defaultValue: 70 },   // admin se change
  memory_threshold: { type: DataTypes.INTEGER, defaultValue: 80 },
  disk_threshold:   { type: DataTypes.INTEGER, defaultValue: 85 },
  tags:          { type: DataTypes.JSONB, defaultValue: {} },
  asg_name:      { type: DataTypes.STRING },  // linked Auto Scaling Group
  last_seen:     { type: DataTypes.DATE },
}, { tableName: 'servers' });
