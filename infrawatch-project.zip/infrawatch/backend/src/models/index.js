// ============================================================
// FILE: /home/infrawatch/backend/src/models/index.js
// PURPOSE: Sequelize + PostgreSQL connection setup
// ============================================================

const { Sequelize } = require('sequelize');

const sequelize = new Sequelize(
  process.env.DB_NAME || 'infrawatch_db',
  process.env.DB_USER || 'infrawatch_user',
  process.env.DB_PASSWORD,
  {
    host:    process.env.DB_HOST || 'localhost',
    port:    parseInt(process.env.DB_PORT) || 5432,
    dialect: 'postgres',
    logging: process.env.NODE_ENV === 'development' ? console.log : false,
    pool: { max: 5, min: 0, acquire: 30000, idle: 10000 },
  }
);

// ── Models Import ─────────────────────────────────────────
const User    = require('./User')(sequelize);
const Server  = require('./Server')(sequelize);
const Alert   = require('./Alert')(sequelize);
const Metric  = require('./Metric')(sequelize);
const ScalingEvent = require('./ScalingEvent')(sequelize);

// ── Associations (Relationships) ──────────────────────────
Server.hasMany(Alert,  { foreignKey: 'server_id', as: 'alerts' });
Alert.belongsTo(Server, { foreignKey: 'server_id', as: 'server' });

Server.hasMany(Metric, { foreignKey: 'server_id', as: 'metrics' });
Metric.belongsTo(Server, { foreignKey: 'server_id', as: 'server' });

Server.hasMany(ScalingEvent, { foreignKey: 'server_id', as: 'scalingEvents' });

module.exports = { sequelize, User, Server, Alert, Metric, ScalingEvent };
