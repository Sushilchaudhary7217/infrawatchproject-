// ============================================================
// FILE: /home/infrawatch/backend/src/models/Alert.js
// ============================================================
const { DataTypes } = require('sequelize');

module.exports = (sequelize) => sequelize.define('Alert', {
  id:          { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  server_id:   { type: DataTypes.UUID, allowNull: false },
  type:        { type: DataTypes.ENUM('cpu','memory','disk','network','instance_down','scaling'), allowNull: false },
  severity:    { type: DataTypes.ENUM('info','warning','critical'), defaultValue: 'warning' },
  message:     { type: DataTypes.TEXT, allowNull: false },
  value:       { type: DataTypes.FLOAT },      // actual value jo trigger hua
  threshold:   { type: DataTypes.FLOAT },      // threshold jo set tha
  status:      { type: DataTypes.ENUM('active','resolved','acknowledged'), defaultValue: 'active' },
  resolved_at: { type: DataTypes.DATE },
  notified:    { type: DataTypes.BOOLEAN, defaultValue: false },
}, { tableName: 'alerts' });

// ============================================================
// FILE: /home/infrawatch/backend/src/models/Metric.js
// ============================================================
const { DataTypes: DT2 } = require('sequelize');
module.exports = (sequelize) => sequelize.define('Metric', {
  id:          { type: DT2.UUID, defaultValue: DT2.UUIDV4, primaryKey: true },
  server_id:   { type: DT2.UUID, allowNull: false },
  cpu_usage:   { type: DT2.FLOAT },
  memory_usage:{ type: DT2.FLOAT },
  disk_usage:  { type: DT2.FLOAT },
  network_in:  { type: DT2.FLOAT },
  network_out: { type: DT2.FLOAT },
  collected_at:{ type: DT2.DATE, defaultValue: DT2.NOW },
}, { tableName: 'metrics', timestamps: false });

// ============================================================
// FILE: /home/infrawatch/backend/src/models/ScalingEvent.js
// ============================================================
const { DataTypes: DT3 } = require('sequelize');
module.exports = (sequelize) => sequelize.define('ScalingEvent', {
  id:          { type: DT3.UUID, defaultValue: DT3.UUIDV4, primaryKey: true },
  server_id:   { type: DT3.UUID },
  asg_name:    { type: DT3.STRING },
  action:      { type: DT3.ENUM('scale_out','scale_in','terminate','launch'), allowNull: false },
  reason:      { type: DT3.TEXT },
  instances_before: { type: DT3.INTEGER },
  instances_after:  { type: DT3.INTEGER },
  triggered_by: { type: DT3.ENUM('auto','manual','alarm'), defaultValue: 'auto' },
  status:      { type: DT3.ENUM('in_progress','success','failed'), defaultValue: 'in_progress' },
}, { tableName: 'scaling_events' });
