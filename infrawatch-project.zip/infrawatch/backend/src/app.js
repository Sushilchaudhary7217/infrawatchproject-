// ============================================================
// FILE: /home/infrawatch/backend/src/app.js
// PURPOSE: Main Express app - sabhi routes aur middleware yahan connect hain
// ============================================================

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const { sequelize } = require('./models');
const authRoutes = require('./routes/auth');
const serverRoutes = require('./routes/servers');
const alertRoutes = require('./routes/alerts');
const metricsRoutes = require('./routes/metrics');
const scalingRoutes = require('./routes/scaling');
const adminRoutes = require('./routes/admin');
const { seedAdminUser } = require('./services/seedService');
const { startMetricsCollector } = require('./services/metricsCollector');

const app = express();
const PORT = process.env.PORT || 3001;

// ── Security Middleware ───────────────────────────────────
app.use(helmet());
app.use(morgan('dev'));

// ── CORS - Frontend ko allow karo ────────────────────────
app.use(cors({
  origin: [
    process.env.FRONTEND_URL || 'http://localhost:3000',
    process.env.ADMIN_URL    || 'http://localhost:3002',
  ],
  credentials: true,
}));

// ── Rate Limiting - DDoS se bachao ───────────────────────
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200,
  message: { error: 'Too many requests, please try again later.' },
});
app.use('/api/', limiter);

// ── Body Parser ───────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Health Check (Nginx/Load Balancer ke liye) ────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    project: 'InfraWatch',
    timestamp: new Date().toISOString(),
    uptime: Math.floor(process.uptime()),
  });
});

// ── API Routes ────────────────────────────────────────────
app.use('/api/auth',    authRoutes);
app.use('/api/servers', serverRoutes);
app.use('/api/alerts',  alertRoutes);
app.use('/api/metrics', metricsRoutes);
app.use('/api/scaling', scalingRoutes);
app.use('/api/admin',   adminRoutes);

// ── 404 Handler ───────────────────────────────────────────
app.use('*', (req, res) => {
  res.status(404).json({ error: 'Route not found', path: req.originalUrl });
});

// ── Global Error Handler ──────────────────────────────────
app.use((err, req, res, next) => {
  console.error('ERROR:', err.message);
  res.status(err.status || 500).json({
    error: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message,
  });
});

// ── Database Connect + Server Start ──────────────────────
async function startServer() {
  try {
    await sequelize.authenticate();
    console.log('✅ Database connected');

    // Tables auto-create (development mein)
    await sequelize.sync({ alter: process.env.NODE_ENV === 'development' });
    console.log('✅ Database synced');

    // Default admin user banao agar exist nahi karta
    await seedAdminUser();

    // AWS metrics har 5 minute mein collect karo
    if (process.env.NODE_ENV !== 'test') {
      startMetricsCollector();
    }

    app.listen(PORT, () => {
      console.log(`\n🚀 InfraWatch Backend running on http://localhost:${PORT}`);
      console.log(`📊 Health check: http://localhost:${PORT}/health`);
      console.log(`🌍 Region: ${process.env.AWS_REGION}`);
      console.log(`🔑 Admin: ${process.env.ADMIN_EMAIL}\n`);
    });
  } catch (err) {
    console.error('❌ Server start failed:', err.message);
    process.exit(1);
  }
}

startServer();
module.exports = app;
