# ============================================================
# FILE: /home/infrawatch/terraform/variables.tf
# PURPOSE: Yahan apni values daalo before terraform apply
# ============================================================

variable "aws_region" {
  description = "AWS Region"
  type        = string
  default     = "ap-south-1"   # Mumbai - aapka region
}

variable "key_pair_name" {
  description = "AWS EC2 Key Pair name - AWS Console se banao"
  type        = string
  default     = "infrawatch-key"   # CHANGE KARO - apna key pair naam
}

variable "alert_email" {
  description = "Email for SNS alerts"
  type        = string
  default     = "your-email@gmail.com"   # CHANGE KARO
}

variable "cpu_threshold" {
  description = "CPU % pe alarm fire hoga"
  type        = number
  default     = 70
}

variable "asg_min" {
  description = "Auto Scaling minimum instances"
  type        = number
  default     = 1
}

variable "asg_max" {
  description = "Auto Scaling maximum instances"
  type        = number
  default     = 3
}

variable "asg_desired" {
  description = "Auto Scaling desired instances"
  type        = number
  default     = 1
}
