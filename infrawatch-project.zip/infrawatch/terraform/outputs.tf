# ============================================================
# FILE: /home/infrawatch/terraform/outputs.tf
# PURPOSE: terraform apply ke baad yeh values screen par aayengi
# ============================================================

output "ec2_public_ip" {
  description = "EC2 instance ka public IP - yahan deploy karo"
  value       = aws_eip.infrawatch.public_ip
}

output "ec2_instance_id" {
  description = "EC2 Instance ID - .env mein daalo"
  value       = aws_instance.infrawatch.id
}

output "sns_topic_arn" {
  description = "SNS Topic ARN - backend .env mein SNS_TOPIC_ARN mein daalo"
  value       = aws_sns_topic.alerts.arn
}

output "s3_bucket_name" {
  description = "S3 Bucket name"
  value       = aws_s3_bucket.infrawatch.bucket
}

output "asg_name" {
  description = "Auto Scaling Group name - admin panel mein use karo"
  value       = aws_autoscaling_group.infrawatch.name
}

output "ssh_command" {
  description = "SSH karne ka command"
  value       = "ssh -i ${var.key_pair_name}.pem ubuntu@${aws_eip.infrawatch.public_ip}"
}

output "next_steps" {
  description = "Ab kya karna hai"
  value       = <<-EOT
    ============================================================
    TERRAFORM COMPLETE! Ab ye steps follow karo:
    ============================================================
    1. SSH: ssh -i ${var.key_pair_name}.pem ubuntu@${aws_eip.infrawatch.public_ip}
    2. Backend .env mein daalo:
       AWS_ACCESS_KEY_ID    = (apni key)
       AWS_SECRET_ACCESS_KEY = (apni secret)
       SNS_TOPIC_ARN        = ${aws_sns_topic.alerts.arn}
    3. Email inbox check karo - SNS subscription confirm karo
    4. scripts/deploy.sh chalao
    ============================================================
  EOT
}
