# ============================================================
# FILE: /home/infrawatch/terraform/main.tf
# PURPOSE: AWS Free Tier infrastructure provision karta hai
# COMMAND: terraform init && terraform plan && terraform apply
# ============================================================

terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
  # Credentials ~/.aws/credentials ya environment variables se
}

# ── Data Sources ──────────────────────────────────────────
data "aws_ami" "ubuntu" {
  most_recent = true
  owners      = ["099720109477"] # Canonical (Ubuntu)
  filter {
    name   = "name"
    values = ["ubuntu/images/hvm-ssd/ubuntu-22.04-amd64-server-*"]
  }
}

# ── Security Group ────────────────────────────────────────
resource "aws_security_group" "infrawatch" {
  name        = "infrawatch-sg"
  description = "InfraWatch security group"

  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]  # Production mein apna IP daalo
    description = "SSH"
  }
  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    description = "HTTP"
  }
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    description = "HTTPS"
  }
  ingress {
    from_port   = 3001
    to_port     = 3001
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    description = "Backend API (dev)"
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = { Name = "infrawatch-sg", Project = "infrawatch" }
}

# ── EC2 Instance (t2.micro - Free Tier) ───────────────────
resource "aws_instance" "infrawatch" {
  ami                    = data.aws_ami.ubuntu.id
  instance_type          = "t2.micro"   # Free tier - 750hr/month
  key_name               = var.key_pair_name
  vpc_security_group_ids = [aws_security_group.infrawatch.id]

  root_block_device {
    volume_size = 20   # GB - free tier 30GB tak
    volume_type = "gp2"
  }

  user_data = base64encode(<<-EOF
    #!/bin/bash
    apt-get update -y
    apt-get install -y nginx nodejs npm postgresql postgresql-contrib git curl
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
    systemctl enable nginx postgresql
    systemctl start nginx postgresql
    echo "InfraWatch setup complete" > /tmp/setup-done.txt
  EOF
  )

  tags = {
    Name    = "InfraWatch-Server"
    Project = "infrawatch"
    Env     = "production"
  }
}

# ── Elastic IP (Static public IP) ─────────────────────────
resource "aws_eip" "infrawatch" {
  instance = aws_instance.infrawatch.id
  domain   = "vpc"
  tags     = { Name = "infrawatch-eip" }
}

# ── S3 Bucket (logs/backups) - 5GB free ──────────────────
resource "aws_s3_bucket" "infrawatch" {
  bucket = "infrawatch-${var.aws_region}-${random_string.suffix.result}"
  tags   = { Project = "infrawatch" }
}

resource "random_string" "suffix" {
  length  = 6
  special = false
  upper   = false
}

resource "aws_s3_bucket_versioning" "infrawatch" {
  bucket = aws_s3_bucket.infrawatch.id
  versioning_configuration { status = "Enabled" }
}

# ── SNS Topic for alerts ──────────────────────────────────
resource "aws_sns_topic" "alerts" {
  name = "InfraWatchAlerts"
  tags = { Project = "infrawatch" }
}

resource "aws_sns_topic_subscription" "email" {
  topic_arn = aws_sns_topic.alerts.arn
  protocol  = "email"
  endpoint  = var.alert_email
}

# ── CloudWatch CPU Alarm ──────────────────────────────────
resource "aws_cloudwatch_metric_alarm" "cpu_high" {
  alarm_name          = "infrawatch-high-cpu"
  comparison_operator = "GreaterThanOrEqualToThreshold"
  evaluation_periods  = 2
  metric_name         = "CPUUtilization"
  namespace           = "AWS/EC2"
  period              = 60
  statistic           = "Average"
  threshold           = var.cpu_threshold
  alarm_description   = "CPU exceeded ${var.cpu_threshold}%"
  alarm_actions       = [aws_sns_topic.alerts.arn]
  ok_actions          = [aws_sns_topic.alerts.arn]

  dimensions = {
    InstanceId = aws_instance.infrawatch.id
  }

  tags = { Project = "infrawatch" }
}

# ── Auto Scaling Group ────────────────────────────────────
resource "aws_launch_template" "infrawatch" {
  name_prefix   = "infrawatch-"
  image_id      = data.aws_ami.ubuntu.id
  instance_type = "t2.micro"
  key_name      = var.key_pair_name

  vpc_security_group_ids = [aws_security_group.infrawatch.id]

  tag_specifications {
    resource_type = "instance"
    tags          = { Name = "InfraWatch-ASG-Instance", Project = "infrawatch" }
  }
}

resource "aws_autoscaling_group" "infrawatch" {
  name                = "InfraWatch-ASG"
  min_size            = var.asg_min
  max_size            = var.asg_max
  desired_capacity    = var.asg_desired
  vpc_zone_identifier = [data.aws_subnet.default.id]

  launch_template {
    id      = aws_launch_template.infrawatch.id
    version = "$Latest"
  }

  health_check_type         = "EC2"
  health_check_grace_period = 300

  tag {
    key                 = "Name"
    value               = "InfraWatch-ASG"
    propagate_at_launch = true
  }
}

data "aws_vpc" "default"    { default = true }
data "aws_subnet" "default" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.default.id]
  }
  filter {
    name   = "default-for-az"
    values = ["true"]
  }
  filter {
    name   = "availabilityZone"
    values = ["${var.aws_region}a"]
  }
}
