# InfraWatch — Auto-Healing AWS Infrastructure Monitor

## Domain: infrawatch.cloud

### Project Structure
```
/home/infrawatch/
├── backend/          Node.js + Express API  → PORT 3001
├── frontend/         React.js Dashboard     → PORT 3000
├── admin-panel/      React.js Admin Panel   → PORT 3002
├── terraform/        AWS Infrastructure as Code
├── nginx/            Nginx reverse proxy config
├── scripts/          Setup + deploy scripts
└── docker-compose.yml
```

---

## STEP 1 — Local Setup (Ubuntu)

```bash
# Dependencies install karo
bash /home/infrawatch/scripts/local-setup.sh

# .env file edit karo
nano /home/infrawatch/backend/.env
# Change: DB_PASSWORD, JWT_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD
# AWS keys abhi dummy rehne do - local test ke liye

# Start karo
bash /home/infrawatch/scripts/start-local.sh
```

**Browser mein kholein:**
- Frontend:    http://localhost:3000
- Admin Panel: http://localhost:3002/admin
- API Health:  http://localhost:3001/health

**Login:** `admin@infrawatch.cloud` / `Admin@InfraWatch2024`

---

## STEP 2 — AWS Free Account Setup

### 2a. AWS Account + IAM User banao
1. https://aws.amazon.com → Free account create karo
2. Console → IAM → Users → Create user
3. Permissions: `AmazonEC2FullAccess`, `CloudWatchFullAccess`, `AmazonSNSFullAccess`, `AutoScalingFullAccess`
4. Security credentials → Create access key → Download CSV

### 2b. AWS CLI Configure karo
```bash
aws configure
# AWS Access Key ID:     [CSV se copy karo]
# AWS Secret Access Key: [CSV se copy karo]
# Default region:        ap-south-1
# Default output format: json

# Test karo
aws ec2 describe-instances --region ap-south-1
```

### 2c. Key Pair banao (SSH ke liye)
```bash
aws ec2 create-key-pair \
  --key-name infrawatch-key \
  --region ap-south-1 \
  --query 'KeyMaterial' \
  --output text > infrawatch-key.pem
chmod 400 infrawatch-key.pem
```

---

## STEP 3 — Terraform se AWS Deploy

```bash
cd /home/infrawatch/terraform

# variables.tf mein apna email daalo
nano variables.tf
# alert_email = "your-email@gmail.com"
# key_pair_name = "infrawatch-key"

# Init + Deploy
terraform init
terraform plan      # pehle review karo
terraform apply     # yes type karo

# Output mein milega:
# ec2_public_ip    = "13.235.x.x"
# sns_topic_arn    = "arn:aws:sns:ap-south-1:..."
# ssh_command      = "ssh -i infrawatch-key.pem ubuntu@13.235.x.x"
```

**Email inbox check karo** — SNS subscription confirm karo!

---

## STEP 4 — EC2 par Deploy

```bash
# backend/.env mein update karo
nano /home/infrawatch/backend/.env
# DB_HOST = localhost (EC2 par local postgres)
# AWS_ACCESS_KEY_ID = apni key
# AWS_SECRET_ACCESS_KEY = apni secret
# SNS_TOPIC_ARN = terraform output se copy karo
# FRONTEND_URL = https://infrawatch.cloud
# ADMIN_URL = https://admin.infrawatch.cloud

# Deploy script chalao
bash /home/infrawatch/scripts/deploy-aws.sh 13.235.x.x infrawatch-key.pem
```

---

## STEP 5 — Domain + SSL

```bash
# SSH karo
ssh -i infrawatch-key.pem ubuntu@13.235.x.x

# Certbot install + SSL
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx \
  -d infrawatch.cloud \
  -d api.infrawatch.cloud \
  -d admin.infrawatch.cloud \
  --email your@email.com --agree-tos --non-interactive
```

**Route 53 ya Namecheap mein DNS set karo:**
```
A    infrawatch.cloud        → 13.235.x.x
A    api.infrawatch.cloud    → 13.235.x.x
A    admin.infrawatch.cloud  → 13.235.x.x
```

---

## Admin Panel — Kya Kya Change Kar Sakte Ho

| Feature | URL | Kya karo |
|---|---|---|
| Server thresholds | /admin/servers | CPU/Memory/Disk alert % change karo |
| Auto Scaling | /admin/scaling | Min/Max instances set karo |
| Manual scale | /admin/scaling | Scale out/in button |
| Users | /admin/users | Team members add/remove karo |
| Test alert | /api/alerts/test | Email delivery test karo |
| Overview | /admin | Live server count + health |

---

## API Quick Reference

```bash
# Login
curl -X POST http://localhost:3001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@infrawatch.cloud","password":"Admin@InfraWatch2024"}'

# Servers list
curl -H "Authorization: Bearer TOKEN" http://localhost:3001/api/servers

# Active alerts
curl -H "Authorization: Bearer TOKEN" http://localhost:3001/api/alerts/active

# Metrics summary
curl -H "Authorization: Bearer TOKEN" http://localhost:3001/api/metrics/summary
```

---

## Resume Description
> Designed and deployed a production-grade Auto-Healing Infrastructure Monitoring system on AWS. Built a Node.js REST API backend with JWT authentication, PostgreSQL database, and real-time CloudWatch metrics collection. Implemented Auto Scaling Groups with SNS email alerts, automatic alarm-triggered scaling, and a React.js dashboard with admin panel for threshold configuration and user management. Provisioned all infrastructure using Terraform (EC2, ASG, SNS, S3, CloudWatch) on AWS Free Tier (ap-south-1). Deployed with Nginx reverse proxy, PM2 process management, and Let's Encrypt SSL.

**Tech Stack:** Node.js, Express, React.js, PostgreSQL, AWS EC2, CloudWatch, SNS, ASG, Terraform, Nginx, Docker, JWT
